var request = require('request-promise');
var cors = require('cors');
var express = require('express');
var url = require('url');//GLOBAL MODULE

var app = express();
var server = app.listen('3000',function(){console.log('Listening to port 3000');});
app.use(cors());

app.get('/getExchangeInfo',runThisCode);
app.get('/getCandleStickData',getKLINEData);


function runThisCode(req,res){
    request({
        method:'GET',
        url: 'https://api.binance.com/api/v1/exchangeInfo',
        resolveWithFullResponse: true
    })
    .then((r1) => {
        res.send(JSON.parse(r1.body));
    })
    .catch()
}

function getKLINEData(req,res){
    var input = url.parse(req.url,true).query;
    
    request({
        method:'GET',
        url: 'https://api.binance.com/api/v1/klines?symbol=' + input.symbol + '&interval=' + input.interval ,
        resolveWithFullResponse: true
    })
    .then((r1) => {
        res.send(JSON.parse(r1.body));
    })
    .catch(err => {
        console.log(err);
    })
}